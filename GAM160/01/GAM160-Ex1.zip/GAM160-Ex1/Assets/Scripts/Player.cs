﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//This script needs a RigidBody2D in order to function
//Require Component will add one, if its not on the Game Object
[RequireComponent(typeof(Rigidbody2D))]
public class Player : MonoBehaviour {

    //Physics
    Rigidbody2D PhysicsBody;
    //Jump Direction
    Vector2 JumpDirection=new Vector2(0.0f,1.0f);
    //Movement
    float JumpSpeed=200.0f;
    float MoveSpeed = 20.0f;

    //Health
    int Health = 100;
    public Text HealthText;

	// Use this for initialization
	void Start () {
        PhysicsBody = GetComponent<Rigidbody2D>();
        SetHealthText();
    }

    //Updated on a regular fixed interval, do all work with Physics in here
    void FixedUpdate()
    {
        //Get the horizontal input from the user
        float inputHorizontal=Input.GetAxis("Horizontal");

        //Use this to call the move function
        Move(new Vector2(inputHorizontal, 0.0f));

        //If Jump has been pressed
        if (Input.GetButtonDown("Jump"))
        {
            Jump();
        }
    }

    //Called when a component needs to be updated
    void Update()
    {
        //If the damage button has been pressed
        if (Input.GetButtonDown("Damage"))
        {
            //Take some damage
            TakeDamage(2);
        }
        //Has the heal button been pressed
        if (Input.GetButtonDown("Heal"))
        {
            HealDamage(2);
        }
    }

    //Jump function, we should really check if we are on the ground before jumping!
    public void Jump()
    {
        PhysicsBody.AddForce(JumpSpeed * JumpDirection);
    }

    //Move function, we should really check if we are on the ground before moving!
    public void Move(Vector2 direction)
    {
        PhysicsBody.AddForce(MoveSpeed * direction);
    }

    //Take some damage
    public void TakeDamage(int health)
    {
        Health -= health;
        SetHealthText();
    }

    //Heal Damage
    public void HealDamage(int health)
    {
        Health += health;
        SetHealthText();
    }


    //Get Health
    public int GetHealth()
    {
        return Health;
    }

    //Update Health UI
    public void SetHealthText()
    {
        HealthText.text = Health.ToString();
    }
}
