﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour {
   
    public float movementForce = 0.005f;
    public float lookScale = 1;

    bool trackMouse = true;
    
    public GameObject grenade;
    
    public float grenadeMass = 1;
    public float grenadeSpeed = 1;
    public float grenadeElevation = 1;

	void Start ()
    {
	}
	
	void Update ()
    {
        var camera = transform.Find("camera");
        var rigidBody = GetComponent<Rigidbody>();

        string debugText = "";
        
        rigidBody.AddForce(camera.transform.transform.forward * movementForce * Input.GetAxis("Vertical"), ForceMode.Impulse);
        rigidBody.AddForce(camera.transform.transform.right * movementForce * Input.GetAxis("Horizontal"), ForceMode.Impulse);

        if (Input.GetButtonDown("Jump"))
        {
            rigidBody.AddForce(Vector3.up * 10, ForceMode.Impulse);
        }

        var rotation = camera.localEulerAngles;

        rotation.y += Input.GetAxis("Mouse X") * lookScale;
        rotation.x -= Input.GetAxis("Mouse Y") * lookScale;

        if ((rotation.x > 30) && (rotation.x < 180))
        {
            rotation.x = 30;
        }

        if ((rotation.x < 330) && (rotation.x > 180))
        {
            rotation.x = 330;
        }

        debugText += rotation.x.ToString("0.0") + ":" + rotation.y.ToString("0.0");

        if (trackMouse == true)
        {           
            camera.localEulerAngles = rotation;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
        else
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }

        if(Input.GetKeyDown(KeyCode.Escape) == true)
        {
            trackMouse = !trackMouse;
        }
                
        if (Input.GetButtonDown("Fire1") == true)
        {
            Debug.LogWarning("Launch grenade");

            if (grenade != null)
            {
                var hitVector = camera.transform.transform.forward;

                hitVector.y *= grenadeElevation;
                hitVector.Normalize();


                var inst = Instantiate(grenade, transform.position + (camera.transform.transform.forward * 2), transform.rotation);

                if(inst != null)
                {
                    inst.GetComponent<Rigidbody>().mass = grenadeMass;
                    inst.transform.GetComponent<Rigidbody>().AddForce(hitVector * grenadeSpeed, ForceMode.Impulse);
                }
            }
        }
        


        if (GameObject.Find("Canvas") != null)
        {
            GameObject.Find("Canvas").GetComponent<canvasController>().debugText = debugText;
        }
    }
}
