﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour {
   
    public float movementForce = 0.005f;
    public float lookScale = 1;

    public bool trackMouse = true;

	void Start ()
    {
		
	}
	
	void Update ()
    {
        var camera = transform.Find("camera");
        var rigidBody = GetComponent<Rigidbody>();

        string debugText = "";
        
        rigidBody.AddForce(camera.transform.transform.forward * movementForce * Input.GetAxis("Vertical"), ForceMode.Impulse);
        rigidBody.AddForce(camera.transform.transform.right * movementForce * Input.GetAxis("Horizontal"), ForceMode.Impulse);

        if (Input.GetButtonDown("Jump"))
        {
            rigidBody.AddForce(Vector3.up * 10, ForceMode.Impulse);
        }

            var rotation = camera.localEulerAngles;

        if (trackMouse == true)
        {
            rotation.y += Input.GetAxis("Mouse X") * lookScale;
            rotation.x -= Input.GetAxis("Mouse Y") * lookScale;
            
            debugText += rotation.x.ToString("0.0") + ":" + rotation.y.ToString("0.0");            

            if ((rotation.x > 30) && (rotation.x < 180))
            {
                rotation.x = 30;
            }

            if ((rotation.x < 330) && (rotation.x > 180))
            {
                rotation.x = 330;
            }

            camera.localEulerAngles = rotation;

            Cursor.lockState = CursorLockMode.Locked;
        }

        if(Input.GetKeyDown(KeyCode.Escape) == true)
        {
            trackMouse = !trackMouse;
            Cursor.lockState = CursorLockMode.None;
        }

        //Let's experiment with raycasting and hits ....


        RaycastHit hit;

        if(Physics.Raycast(transform.position, camera.transform.transform.forward, out hit,float.MaxValue) == true)
        {
            debugText += "\n"+hit.transform.gameObject.name;                
        }

        if (GameObject.Find("Canvas") != null)
        {
            GameObject.Find("Canvas").GetComponent<canvasController>().debugText = debugText;
        }
    }
}
