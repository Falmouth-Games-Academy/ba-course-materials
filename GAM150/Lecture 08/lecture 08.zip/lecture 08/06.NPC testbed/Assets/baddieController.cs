﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class baddieController : MonoBehaviour
{

    // Use this for initialization
    
    UnityEngine.AI.NavMeshAgent agent;
    LineRenderer line;

    public Color normalColour;
    public Color selectedColour;

    const string Action_WorkoutWhereToGo = "workoutwheretogo";
    const string Action_GoToTarget = "gototarget";

    bool hasRoute = false;

    void Start()
    {
        line = this.gameObject.AddComponent<LineRenderer>();
        line.material = new Material(Shader.Find("Sprites/Default")) { color = Color.yellow };
        line.startWidth = 0.5f;
        line.endWidth = 0.5f;
        line.startColor = Color.yellow;
        line.endColor = Color.yellow;

        agent = this.GetComponent<UnityEngine.AI.NavMeshAgent>();        
    }
    
    void Update()
    {
        switch (DecideWhatToDo())
        {
            case Action_WorkoutWhereToGo:
                {
                    UnityEngine.Random.InitState((int)System.DateTime.Now.Ticks);

                    bool validDest = false;
                    int tries = 0;

                    while ((validDest == false) && (tries < 100) )
                    {
                        var dest = new Vector3(UnityEngine.Random.Range(-20.0f, 20.0f)
                                         , 0.07f
                                         , UnityEngine.Random.Range(-20.0f, 20.0f));

                        var hits = Physics.RaycastAll(dest, new Vector3(0, -1, 0));

                        var result = Array.Find<RaycastHit>(hits, s => s.collider.gameObject.name.ToLower().Contains("walls"));

                        if (result.collider == null)
                        {
                            validDest = true;

                            GetComponent<UnityEngine.AI.NavMeshAgent>().SetDestination(dest);

                            hasRoute = true;
                        }

                        tries++;
                    }
                }
                break;

            case Action_GoToTarget:
                {                    
                    if (!agent.pathPending)
                    {
                        if (agent.remainingDistance <= agent.stoppingDistance)
                        {
                            hasRoute = false;
                        }
                    }

                    DrawRoutePath();                    
                }
                break;
        }

        if(GameObject.Find("levelController").GetComponent<levelController>().amISelected(gameObject) == true)
        {
            GetComponent<MeshRenderer>().materials[0].SetColor("_Color", selectedColour);
        }
        else
        {
            GetComponent<MeshRenderer>().materials[0].SetColor("_Color", normalColour);
        }
    }

    void DrawTargetPath()
    {        
        Debug.DrawLine(transform.position, GameObject.Find("Player").transform.position, Color.red);        
    }

    void DrawRoutePath()
    {         
        var path = agent.path;

        line.positionCount = path.corners.Length;        

        for (int i = 0; i < path.corners.Length; i++)
        {
            line.SetPosition(i, path.corners[i]);
        }
    }
    

    string DecideWhatToDo()
    {
        if (hasRoute == true)
        {
            return Action_GoToTarget;
        }

        return Action_WorkoutWhereToGo;
    }

    public void OnDeath()
    {
        GameObject.Destroy(gameObject);
    }
}
