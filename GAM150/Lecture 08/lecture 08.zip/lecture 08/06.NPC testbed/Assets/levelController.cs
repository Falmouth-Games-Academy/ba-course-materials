﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class levelController : MonoBehaviour
{
    public GameObject baddie;

    [HideInInspector]
    List<GameObject> selectedBaddies = new List<GameObject>();

    void Start()
    {

    }
    
    void Update()
    {
        RaycastHit[] hits;

        var pos = GameObject.Find("Main Camera").GetComponent<Camera>().ScreenPointToRay(Input.mousePosition);

        hits = Physics.RaycastAll(pos);

        selectedBaddies.Clear();
                        
        if (hits.Length > 0)
        {
            foreach(var hit in hits)
            {
                if(hit.collider.gameObject.name.ToLower().Contains("baddie") == true)
                {
                    selectedBaddies.Add(hit.collider.gameObject);
                }
            }
        }

        if (Input.GetButtonDown("Fire1") == true)
        {                        
            if (hits.Length > 0)
            {
                var result = Array.Find<RaycastHit>(hits, s => s.collider.gameObject.name.ToLower().Contains("walls"));

                if (result.collider == null)
                {
                    var inst = Instantiate(baddie, hits[0].point, Quaternion.Euler(0, 0, 0));                    
                }
            }
        }

        if (Input.GetButtonDown("Fire2") == true)
        {
            foreach(var baddie in selectedBaddies)
            {
                baddie.GetComponent<baddieController>().OnDeath();
            }
        }
    }

    public bool amISelected(GameObject baddie)
    {
        return selectedBaddies.Contains(baddie);
    }
}
