﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class newplatformscript : MonoBehaviour {

    [Range(0, 1)]
    public float offset;

    // Use this for initialization
    void Start()
    {
        var anim = GetComponent<Animation>();

        anim["platform_horizontal"].time = offset;
        GetComponent<Animation>().Play();
    }

    // Update is called once per frame
    void Update () {
		
	}

    public void OnEvent(string s)
    {
        var audio = GetComponent<AudioSource>();

        //GetComponent<AudioSource>().Play();        
    }
}
