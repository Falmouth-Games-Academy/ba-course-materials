﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class animatedToothController : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        var anim = GetComponent<Animation>();               
	}

    public void animationEvent(int val)
    {

    }
}
