﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class playerController : MonoBehaviour
{
    public float speed = 6.0F;
    public float jumpSpeed = 8.0F;
    public float gravity = 20.0F;
    
    Vector3 moveDirection = Vector3.zero;
    bool onPlatform;

    void Start()
    {
        onPlatform = false;
    }

    void Update()
    {
        GetComponent<MeshRenderer>().materials[0].color = Color.red;

        CharacterController controller = GetComponent<CharacterController>();
        if (controller.isGrounded)
        {
            moveDirection = new Vector3(Input.GetAxis("Horizontal"), 0, 0);
            moveDirection *= speed;
            
            if (Input.GetButtonDown("Jump"))
            {
                moveDirection.y = jumpSpeed;                
                onPlatform = false;
            }

            GetComponent<MeshRenderer>().materials[0].color = Color.green;
        }

        var list = GameObject.FindObjectsOfType<GameObject>();

        foreach (var entry in list)
        {
            if (entry.name.ToLower().Contains("platform") == true)
            {
                if (onPlatform == true)
                {
                    Physics.IgnoreCollision(controller, entry.GetComponent<Collider>(), false);
                }
                else
                {
                    Physics.IgnoreCollision(controller, entry.GetComponent<Collider>(), controller.velocity.y > 0);
                }
            }
        }

        if ((onPlatform == false) || (controller.velocity.y < 0))
        {
            this.transform.parent = null;
        }

        GameObject.Find("debug_text").GetComponent<UnityEngine.UI.Text>().text = controller.velocity.y.ToString()
            +"\n" + controller.isGrounded;

        moveDirection.y -= gravity * Time.deltaTime;
        controller.Move(moveDirection * Time.deltaTime);
    }

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.gameObject.name.ToLower().Contains("platform") == true)
        {
            if (this.transform.position.y > hit.transform.position.y)
            {
                this.transform.parent = hit.transform;

                onPlatform = true;
            }
        }
        else
        {
            onPlatform = false;
        }

    }

    private void OnTriggerEnter(Collider other)
    {        
        if(other.name.ToLower().Contains("hazard_fall_of_death") == true)
        {
            Debug.LogWarning("fall of death");
            GameObject.Find("gameController").GetComponent<gameController>().OnDeath();            
        }

        if (other.name.ToLower().Contains("hazard_death_cube") == true)
        {
            Debug.LogWarning("touched the cube of death");
            GameObject.Find("gameController").GetComponent<gameController>().OnDeath();
        }
    }
}
