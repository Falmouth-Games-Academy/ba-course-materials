﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class teethController : MonoBehaviour
{
    [Range(-0.1f,0.1f)]
    public float speed;

    public float range;
    int direction;
    
    public Vector3 position;

	void Start ()
    {
        direction = 1;
        this.transform.position = position;
	}
	
	void Update ()
    {
        var travel = this.transform.position.y - position.y;

        if ((travel > range) || (travel <0))
        {
            this.direction *= -1;
        }

        var temp = this.transform.position;

        temp.y += direction * speed * Time.timeScale;

        this.transform.position = temp;
    }
}
