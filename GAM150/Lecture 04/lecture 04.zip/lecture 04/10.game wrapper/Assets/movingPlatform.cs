﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movingPlatform : MonoBehaviour
{    
    [Range(-0.1f,0.1f)]
    public float speed;
    int direction;
       
    void Start ()
    {
        this.transform.position = new Vector3(2.26f, -2.2f, 0);
        direction = 1;
	}
	
	void Update ()
    {
        if ((this.transform.position.x > 4.7f) || (this.transform.position.x < -0.75f))
        {
            direction *= -1;
        }

        var temp = this.transform.position;

        temp.x += direction * speed * Time.timeScale;

        this.transform.position = temp;
    }
}
