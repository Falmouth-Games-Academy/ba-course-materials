﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class toothOfDeath : MonoBehaviour {

    [Range(-0.1f, 0.1f)]
    public float speed;

    int direction;
    void Start()
    {
        direction = 1;        
    }

    void Update()
    {        
        var temp = this.transform.localScale;

        if((temp.y < 0) || (temp.y > 1))
        {
            direction *= -1;
        }

        temp.y += direction * speed * Time.timeScale;

        this.transform.localScale = temp;

        this.transform.Find("hazard_death_cube (1)").GetComponent<MeshRenderer>().materials[0].color = new Color(1, 0, 0, 0.1f);
    }
}
