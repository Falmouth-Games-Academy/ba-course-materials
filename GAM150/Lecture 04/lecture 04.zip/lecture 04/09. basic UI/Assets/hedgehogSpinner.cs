﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hedgehogSpinner : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}

    float z = 0;
		
	void Update ()
    {
        z += Time.deltaTime*100;

        transform.rotation = Quaternion.Euler(0, 0, z);
    }
}
