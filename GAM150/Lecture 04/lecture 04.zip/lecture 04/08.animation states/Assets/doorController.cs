﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class doorController : MonoBehaviour
{
    bool isPlayerOnTrigger;
    
    void Start()
    {
        isPlayerOnTrigger = false;
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void OnEnterDoorTrigger()
    {
        isPlayerOnTrigger = true;
    }

    public void OnExitDoorTrigger()
    {
        isPlayerOnTrigger = false;
    }

    public void OnEndOfAnimation(string name)
    {
        Debug.LogWarning(name);

        if (name == "door_closed")
        {
            if(isPlayerOnTrigger == true)
            {
                transform.Find("door_object").GetComponent<Animation>().Play("door_closed_to_open", PlayMode.StopAll);
            }
            else
            {
                transform.Find("door_object").GetComponent<Animation>().Play("door_closed", PlayMode.StopAll);
            }
        }

        if (name == "door_open")
        {
            if (isPlayerOnTrigger == true)
            {
                transform.Find("door_object").GetComponent<Animation>().Play("door_open");
            }
            else
            {
                transform.Find("door_object").GetComponent<Animation>().Play("door_open_to_closed");
            }
        }

        if (name == "door_open_to_closed")
        {
            if (isPlayerOnTrigger == true)
            {
                transform.Find("door_object").GetComponent<Animation>().Play("door_closed_to_open");
            }
            else
            {
                transform.Find("door_object").GetComponent<Animation>().Play("door_closed");
            }
        }

        if (name == "door_closed_to_open")
        {
            if (isPlayerOnTrigger == true)
            {
                transform.Find("door_object").GetComponent<Animation>().Play("door_open");
            }
            else
            {
                transform.Find("door_object").GetComponent<Animation>().Play("door_open_to_closed");
            }
        }
    }
}
