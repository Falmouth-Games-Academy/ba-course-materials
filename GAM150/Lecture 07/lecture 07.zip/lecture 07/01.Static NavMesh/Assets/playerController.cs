﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetMouseButtonDown(0) == true)
        {
            RaycastHit[] hits;

            var pos = GameObject.Find("Main Camera").GetComponent<Camera>().ScreenPointToRay(Input.mousePosition);

            hits = Physics.RaycastAll(pos);

            if(hits.Length > 0)
            {
                foreach (var hit in hits)
                {
                    Debug.LogWarning(hit.collider.gameObject.name);
                }

                var result = Array.Find<RaycastHit>(hits, s => s.collider.gameObject.name.ToLower().Contains("walls"));

                if(result.collider == null)
                {                
                    foreach (var hit in hits)
                    {
                        GetComponent<UnityEngine.AI.NavMeshAgent>().SetDestination(hit.point);
                    }
                }
            }
        }

        OnDrawGizmosSelected();

    }

    //from https://answers.unity.com/questions/361810/draw-path-along-navmesh-agent-path.html

    void OnDrawGizmosSelected()
    {

        var nav = GetComponent<UnityEngine.AI.NavMeshAgent>();
        if (nav == null || nav.path == null)
            return;

        var line = this.GetComponent<LineRenderer>();
        if (line == null)
        {
            line = this.gameObject.AddComponent<LineRenderer>();
            line.material = new Material(Shader.Find("Sprites/Default")) { color = Color.yellow };
            line.SetWidth(0.5f, 0.5f);
            line.SetColors(Color.yellow, Color.yellow);
        }

        var path = nav.path;

        line.SetVertexCount(path.corners.Length);

        for (int i = 0; i < path.corners.Length; i++)
        {
            line.SetPosition(i, path.corners[i]);
        }

    }
}
