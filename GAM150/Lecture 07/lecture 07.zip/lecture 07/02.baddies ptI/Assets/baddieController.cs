﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class baddieController : MonoBehaviour {

    public Vector3[] waypoints;

    int nextTarget = 0;

	void Start ()
    {
	    if(waypoints.Length > 0)
        {
            var agent = GetComponent<UnityEngine.AI.NavMeshAgent>();
            this.transform.position = waypoints[nextTarget];

            nextTarget = (nextTarget + 1) % waypoints.Length;
            agent.SetDestination(waypoints[nextTarget]);
        }
	}
		
	void Update ()
    {
        var agent = GetComponent<UnityEngine.AI.NavMeshAgent>();

        if (waypoints.Length > 0)
        {
            if (!agent.pathPending)
            {
                if (agent.remainingDistance <= agent.stoppingDistance)
                {
                    if (!agent.hasPath || agent.velocity.sqrMagnitude == 0f)
                    {
                        // Done
                        nextTarget = (nextTarget + 1) % waypoints.Length;
                        agent.SetDestination(waypoints[nextTarget]);
                    }
                }
            }
        }

        DrawRoutePath();
    }

    //from https://answers.unity.com/questions/361810/draw-path-along-navmesh-agent-path.html

    void DrawRoutePath()
    {

        var nav = GetComponent<UnityEngine.AI.NavMeshAgent>();
        if (nav == null || nav.path == null)
            return;

        var line = this.GetComponent<LineRenderer>();
        if (line == null)
        {
            line = this.gameObject.AddComponent<LineRenderer>();
            line.material = new Material(Shader.Find("Sprites/Default")) { color = Color.yellow };
            line.SetWidth(0.5f, 0.5f);
            line.SetColors(Color.yellow, Color.yellow);
        }

        var path = nav.path;

        line.SetVertexCount(path.corners.Length);

        for (int i = 0; i < path.corners.Length; i++)
        {
            line.SetPosition(i, path.corners[i]);
        }
    }
}
