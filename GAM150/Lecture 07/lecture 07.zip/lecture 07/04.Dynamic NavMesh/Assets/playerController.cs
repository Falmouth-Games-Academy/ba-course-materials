﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetMouseButtonDown(0) == true)
        {
            RaycastHit[] hits;

            var pos = GameObject.Find("Main Camera").GetComponent<Camera>().ScreenPointToRay(Input.mousePosition);

            hits = Physics.RaycastAll(pos);

            if(hits.Length > 0)
            {


                foreach (var hit in hits)
                {
                    Debug.LogWarning(hit.collider.gameObject.name);
                }

                var result = Array.Find<RaycastHit>(hits, s => s.collider.gameObject.name.ToLower().Contains("walls"));

                if(result.collider == null)
                {                
                    foreach (var hit in hits)
                    {
                        GetComponent<UnityEngine.AI.NavMeshAgent>().SetDestination(hit.point);
                    }
                }
            }
        }		
	}
}
