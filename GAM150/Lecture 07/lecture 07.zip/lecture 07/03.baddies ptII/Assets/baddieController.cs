﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class baddieController : MonoBehaviour {

    // Use this for initialization
    public Vector3[] nodes;
    public int nextTarget;

    void Start()
    {
        if (nodes.Length > 0)
        {
            var agent = GetComponent<UnityEngine.AI.NavMeshAgent>();
            this.transform.position = nodes[nextTarget];

            nextTarget = (nextTarget + 1) % nodes.Length;
            agent.SetDestination(nodes[nextTarget]);
        }
    }

    // Update is called once per frame
    void Update ()
    {
        var agent = GetComponent<UnityEngine.AI.NavMeshAgent>();

        if (nodes.Length > 0)
        {        
            if (!agent.pathPending)
            {
                if (agent.remainingDistance <= agent.stoppingDistance)
                {
                    if (!agent.hasPath || agent.velocity.sqrMagnitude == 0f)
                    {
                        // Done
                        nextTarget = (nextTarget + 1) % nodes.Length;
                        agent.SetDestination(nodes[nextTarget]);
                    }
                }
            }
        }

        {            
            var line = this.GetComponent<LineRenderer>();
            if (line == null)
            {
                line = this.gameObject.AddComponent<LineRenderer>();
                line.material = new Material(Shader.Find("Sprites/Default")) { color = Color.yellow };
                line.SetWidth(0.5f, 0.5f);
                line.SetColors(Color.yellow, Color.yellow);
            }

            var path = agent.path;

            line.SetVertexCount(path.corners.Length);

            for (int i = 0; i < path.corners.Length; i++)
            {
                line.SetPosition(i, path.corners[i]);
            }
        }

        {
            var dir = GameObject.Find("Player").transform.position - transform.position;
            dir.Normalize();
            RaycastHit hit;

            Physics.Raycast(transform.position, dir, out hit);

            if(hit.collider != null)              
            {
                var col = hit.collider.gameObject.name.ToLower().Contains("player") ? Color.red : Color.green;
                Debug.DrawLine(transform.position, hit.point, col);

                if (hit.collider.gameObject.name.ToLower().Contains("player") == true)
                {
                    agent.SetDestination(transform.position);
                }
                else
                {
                    agent.SetDestination(nodes[nextTarget]);
                }
            }
        }
    }
}
