﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class baddieController : MonoBehaviour {

    // Use this for initialization
    public Vector3[] nodes;
    public int nextTarget;

    UnityEngine.AI.NavMeshAgent agent;
    LineRenderer line;

    const string Action_Look = "look";
    const string Action_Patrol = "patrol";

    void Start()
    {
        line = this.gameObject.AddComponent<LineRenderer>();
        line.material = new Material(Shader.Find("Sprites/Default")) { color = Color.yellow };
        line.startWidth = 0.5f;
        line.endWidth = 0.5f;
        line.startColor = Color.yellow;
        line.endColor = Color.yellow;

        agent = this.GetComponent<UnityEngine.AI.NavMeshAgent>();

        if (nodes.Length > 0)
        {
            this.transform.position = nodes[nextTarget];

            nextTarget = (nextTarget + 1) % nodes.Length;
            agent.SetDestination(nodes[nextTarget]);
        }
    }
    
    void Update()
    {
        switch (DecideWhatToDo())
        {
            case Action_Look:
                {
                    agent.SetDestination(transform.position);
                    DrawTargetPath();
                }
                break;

            case Action_Patrol:
                {
                    if (nodes.Length > 0)
                    {
                        if (!agent.pathPending)
                        {
                            if (agent.remainingDistance <= agent.stoppingDistance)
                            {
                                if (!agent.hasPath || agent.velocity.sqrMagnitude == 0f)
                                {
                                    nextTarget = (nextTarget + 1) % nodes.Length;
                                    agent.SetDestination(nodes[nextTarget]);
                                }
                            }
                        }

                        DrawRoutePath();
                    }
                }
                break;
        }
    }

    void DrawTargetPath()
    {        
        Debug.DrawLine(transform.position, GameObject.Find("Player").transform.position, Color.red);        
    }

    void DrawRoutePath()
    {         
        var path = agent.path;

        line.positionCount = path.corners.Length;        

        for (int i = 0; i < path.corners.Length; i++)
        {
            line.SetPosition(i, path.corners[i]);
        }
    }
    

    string DecideWhatToDo()
    {
        var dir = GameObject.Find("Player").transform.position - transform.position;
        dir.Normalize();
        RaycastHit hit;

        Physics.Raycast(transform.position, dir, out hit);

        if(hit.collider != null)              
        {            
            if (hit.collider.gameObject.name.ToLower().Contains("player") == true)
            {
                return Action_Look;
            }                      
        }

        return Action_Patrol;
    }
}
