﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour
{   
    public float movementForce = 0.005f;
    public float lookScale = 1;

    void Update ()
    {
        var rigidBody = GetComponent<Rigidbody>();
        
        rigidBody.AddForce(transform.forward * movementForce * Input.GetAxis("Vertical"), ForceMode.Impulse);
        rigidBody.AddForce(transform.right * movementForce * Input.GetAxis("Horizontal"), ForceMode.Impulse);


        var playerRotation = transform.localEulerAngles;        

        playerRotation.y += Input.GetAxis("Mouse X") * lookScale;

        transform.localEulerAngles = playerRotation;


        var camera = transform.Find("camera");

        var cameraRotation = camera.transform.localEulerAngles;

        cameraRotation.x += Input.GetAxis("Mouse Y") * lookScale;

        if ((cameraRotation.x > 30) && (cameraRotation.x < 180))
        {
            cameraRotation.x = 30;
        }

        if ((cameraRotation.x < 330) && (cameraRotation.x > 180))
        {
            cameraRotation.x = 330;
        }

        camera.transform.localEulerAngles = cameraRotation;

        if (GameObject.Find("Canvas") != null)
        {
            var debugText = "";

            debugText += cameraRotation.x.ToString("0.0");
            GameObject.Find("Canvas").GetComponent<canvasController>().debugText = debugText;
        }
        

    }
}
