﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour
{   
    public float movementForce = 0.005f;
    public float lookScale = 1;

    void Update ()
    {
        var rigidBody = GetComponent<Rigidbody>();
        
        rigidBody.AddForce(transform.forward * movementForce * Input.GetAxis("Vertical"), ForceMode.Impulse);
        rigidBody.AddForce(transform.right * movementForce * Input.GetAxis("Horizontal"), ForceMode.Impulse);


        var playerRotation = transform.localEulerAngles;        

        playerRotation.y += Input.GetAxis("Mouse X") * lookScale;

        transform.localEulerAngles = playerRotation;


        var camera = transform.Find("camera");

        var cameraRotation = camera.transform.localEulerAngles;

        cameraRotation.x += Input.GetAxis("Mouse Y") * lookScale;

        camera.transform.localEulerAngles = cameraRotation;

    }
}
