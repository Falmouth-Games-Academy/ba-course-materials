﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour {
   
    public float movementForce = 0.005f;
    public float lookScale = 1;

    public bool trackMouse = true;

	void Start ()
    {
		
	}
	
	void Update ()
    {
        var camera = transform.Find("camera");
        var rigidBody = GetComponent<Rigidbody>();

        string debugText = "";
        
        rigidBody.AddForce(transform.forward * movementForce * Input.GetAxis("Vertical"), ForceMode.Impulse);
        rigidBody.AddForce(transform.right * movementForce * Input.GetAxis("Horizontal"), ForceMode.Impulse);

        if (Input.GetButtonDown("Jump"))
        {
            rigidBody.AddForce(Vector3.up * 10, ForceMode.Impulse);
        }

            

        if (trackMouse == true)
        {
            var playerRotation = transform.localEulerAngles;
            var cameraRotation = camera.localEulerAngles;

            
            playerRotation.y += Input.GetAxis("Mouse X") * lookScale;

            transform.localEulerAngles = playerRotation;
                

            cameraRotation.x -= Input.GetAxis("Mouse Y") * lookScale;

            debugText += cameraRotation.x.ToString("0.0") + ":" + playerRotation.y.ToString("0.0");

            if ((cameraRotation.x > 30) && (cameraRotation.x < 180))
            {
                cameraRotation.x = 30;
            }

            if ((cameraRotation.x < 330) && (cameraRotation.x > 180))
            {
                cameraRotation.x = 330;
            }

            camera.localEulerAngles = cameraRotation;
            
            Cursor.lockState = CursorLockMode.Locked;
        }
        else
        {
            Cursor.lockState = CursorLockMode.None;
        }

        if(Input.GetKeyDown(KeyCode.Escape) == true)
        {
            trackMouse = !trackMouse;
        }
        

        if (GameObject.Find("Canvas") != null)
        {
            GameObject.Find("Canvas").GetComponent<canvasController>().debugText = debugText;
        }
    }
}
